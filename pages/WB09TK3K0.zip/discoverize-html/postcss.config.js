/*
* @Author: faiqfardian
* @Date:   2018-09-26 16:32:43
* @Last Modified by:   faiqfardian
* @Last Modified time: 2018-09-26 16:46:21
*/
module.exports = (ctx) => ({
  plugins: {
    autoprefixer: {
      cascade: false
    }
  }
})